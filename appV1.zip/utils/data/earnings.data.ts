export const earningsData = [
  { month: 'Jan', value: 75000 },
  { month: 'Feb', value: 25000 },
  { month: 'Mar', value: 45000 },
  { month: 'Apr', value: 15000 },
  { month: 'May', value: 85000 },
  { month: 'Jun', value: 35000 },
  { month: 'Jul', value: 70000 },
  { month: 'Aug', value: 20000 },
  { month: 'Sep', value: 55000 },
  { month: 'Oct', value: 30000 },
  { month: 'Nov', value: 45000 },
  { month: 'Dec', value: 30000 },
];
