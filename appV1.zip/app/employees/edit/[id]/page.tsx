"use client";

import { useParams, useRouter } from 'next/navigation';
import { useState } from 'react';
import { employeesData } from '@/utils/data/employees.data';
import Button from '@/components/(Inputs)/Button/Button';
import FileUpload from '@/components/FileUpload/FileUpload';
import styles from './edit.module.css';

export default function EditEmployeePage() {
  const params = useParams();
  const router = useRouter();
  const decodedId = decodeURIComponent(params.id as string);
  const employee = employeesData.find(e => e.id === decodedId);

  const [files, setFiles] = useState<File[]>([]);
  const [formData, setFormData] = useState({
    firstName: employee?.name.split(' ')[0] || '',
    lastName: employee?.name.split(' ').slice(1).join(' ') || '',
    employeeId: employee?.id || '',
    email: employee?.email || '',
    contact: employee?.contact || '',
    department: employee?.department || '',
    position: employee?.position || '',
    hireDate: employee?.hireDate || '',
    status: employee?.status || '',
    salary: ''
  });

  if (!employee) {
    return <div>Employee not found</div>;
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Updated employee:', formData);
    alert('Employee updated successfully!');
    router.push('/employees');
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1 className={styles.title}>Edit Employee</h1>
      </div>
      <form onSubmit={handleSubmit} className={styles.form}>
        <div className={styles.section}>
          <h3 className={styles.sectionTitle}>Employee Image</h3>
          <FileUpload
            label=""
            files={files}
            setFiles={setFiles}
            accept="image/*"
          />
        </div>
        <div className={styles.section}>
          <h3 className={styles.sectionTitle}>Employee Information</h3>
          <div className={styles.grid}>
            <div className={styles.field}>
              <label>First Name</label>
              <input
                type="text"
                name="firstName"
                placeholder="Enter first name"
                value={formData.firstName}
                onChange={handleChange}
                required
              />
            </div>
            <div className={styles.field}>
              <label>Last Name</label>
              <input
                type="text"
                name="lastName"
                placeholder="Enter last name"
                value={formData.lastName}
                onChange={handleChange}
                required
              />
            </div>
            <div className={styles.field}>
              <label>Employee ID</label>
              <input
                type="text"
                name="employeeId"
                placeholder="Enter ID"
                value={formData.employeeId}
                onChange={handleChange}
                required
              />
            </div>
            <div className={styles.field}>
              <label>Email</label>
              <input
                type="email"
                name="email"
                placeholder="Enter email address"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className={styles.field}>
              <label>Contact</label>
              <input
                type="tel"
                name="contact"
                placeholder="Enter contact number"
                value={formData.contact}
                onChange={handleChange}
                required
              />
            </div>
            <div className={styles.field}>
              <label>Department</label>
              <select
                name="department"
                value={formData.department}
                onChange={handleChange}
                required
              >
                <option value="">Select department</option>
                <option value="Sales">Sales</option>
                <option value="Marketing">Marketing</option>
                <option value="IT">IT</option>
                <option value="Finance">Finance</option>
                <option value="HR">HR</option>
                <option value="Operations">Operations</option>
              </select>
            </div>
            <div className={styles.field}>
              <label>Position</label>
              <select
                name="position"
                value={formData.position}
                onChange={handleChange}
                required
              >
                <option value="">Select position</option>
                <option value="Manager">Manager</option>
                <option value="Executive">Executive</option>
                <option value="Developer">Developer</option>
                <option value="Designer">Designer</option>
                <option value="Analyst">Analyst</option>
                <option value="Coordinator">Coordinator</option>
              </select>
            </div>
            <div className={styles.field}>
              <label>Hire Date</label>
              <input
                type="date"
                name="hireDate"
                value={formData.hireDate}
                onChange={handleChange}
                required
              />
            </div>
            <div className={styles.field}>
              <label>Status</label>
              <select
                name="status"
                value={formData.status}
                onChange={handleChange}
                required
              >
                <option value="">Select status</option>
                <option value="Full Time">Full Time</option>
                <option value="Part Time">Part Time</option>
                <option value="Internship">Internship</option>
                <option value="Remote">Remote</option>
              </select>
            </div>
            <div className={styles.field}>
              <label>Salary</label>
              <input
                type="number"
                name="salary"
                placeholder="Enter salary"
                value={formData.salary}
                onChange={handleChange}
                required
              />
            </div>
          </div>
        </div>
        <div className={styles.actions}>
          <Button variant="primary" type="submit" size="md">
            Update Employee
          </Button>
          <Button variant="danger" type="button" size="md" onClick={() => router.push('/employees')}>
            Cancel
          </Button>
        </div>
      </form>
    </div>
  );
}
